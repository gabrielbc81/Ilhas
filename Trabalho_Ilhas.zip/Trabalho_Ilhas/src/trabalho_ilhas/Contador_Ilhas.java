
public class Contador_Ilhas {

	public static void main(String[] args) {
        Ilhas ilhas = new Ilhas("D:\\Senac\\Workspace\\Algoritimo e Programacao III\\Trabalho01\\src\\exemplo_3.txt");

        System.out.println(ilhas.getIlhas()); 
	}

}
